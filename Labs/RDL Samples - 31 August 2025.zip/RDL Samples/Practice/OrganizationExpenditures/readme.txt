https://learn.microsoft.com/en-us/power-bi/paginated-reports/paginated-reports-samples#organization-expenditures

