https://learn.microsoft.com/en-us/power-bi/paginated-reports/paginated-reports-samples#mailing-letter

This self-contained paginated report sample is designed for creating real world mailing letters. The scenario for this report is that you want a print-ready letter with dynamic content.

This sample has unique characteristics, such as:

• A rectangular data region is placed at different sections of the report body.
• Images to personalize the letter.
• A tablix data region (the data region underlying both tables and matrixes). The tablix displays dynamically generated user-specific content.
• Report items such as text boxes and lines.
• A report parameter to select the content dynamically. The content that is shown applies to a specific subject by using expression placeholders.