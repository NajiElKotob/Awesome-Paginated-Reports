https://learn.microsoft.com/en-us/power-bi/paginated-reports/paginated-reports-samples#labels


Label reports are simple, but have a few unique characteristics to create a paginated label:

A tablix with a fixed column count of three, with defined column spacing.
A rectangular data region that repeats across rows and columns on the printed page.
A report parameter to select the content to be shown in each rectangular data region.